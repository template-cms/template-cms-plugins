<?php
define('TEMPLATE_CMS_ACCESS', true);
define('ROOT', '../../../../');

?>