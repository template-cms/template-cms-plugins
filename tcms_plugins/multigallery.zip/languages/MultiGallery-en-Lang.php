<?php

    $lang['MultiGallery_submenu'] = 'Galleries';
    $lang['MultiGallery_name'] = 'MultiGallery';
    $lang['MultiGallery_thumbnail_width'] = 'width';
    $lang['MultiGallery_thumbnail_height'] = 'height';
    $lang['MultiGallery_thumbnail_count'] = 'count fotos';
    $lang['MultiGallery_save_options'] = 'Save option';
    $lang['MultiGallery_upload'] = 'Upload';
    $lang['MultiGallery_nasv'] = 'Name';
    $lang['MultiGallery_desc'] = 'Description';
    $lang['MultiGallery_edit'] = 'Edit';
    $lang['MultiGallery_gallery'] = 'Galleries';
    $lang['MultiGallery_change_desc'] = 'Save';
    $lang['MultiGallery_create'] = 'Create';
    $lang['MultiGallery_empty'] = 'Gallery is empty!';
    $lang['MultiGallery_foto'] = ' foto';
    $lang['MultiGallery_nofoto'] = 'Nothing here';
    $lang['MultiGallery_teg'] = 'Tag to insert into the content:';
    $lang['MultiGallery_teg_all'] = 'All image galleries ';
    $lang['MultiGallery_teg_gal'] = 'Links to the gallery ';
    $lang['MultiGallery_publish'] = ' Published ';
    $lang['MultiGallery_teg_rand'] = ' Random image from gallery ';
    $lang['MultiGallery_nasv_gal'] = ' Gallery name ';