<?php

    $lang['MultiGallery_submenu'] = 'Галереи';
    $lang['MultiGallery_name'] = 'MultiGallery';
    $lang['MultiGallery_thumbnail_width'] = 'Высота превью';
    $lang['MultiGallery_thumbnail_height'] = 'Ширина превью';
    $lang['MultiGallery_thumbnail_count'] = 'Количество фото';
    $lang['MultiGallery_save_options'] = 'Сохранить опции';
    $lang['MultiGallery_upload'] = 'Загрузить';
    $lang['MultiGallery_nasv'] = 'Название';
    $lang['MultiGallery_desc'] = 'Описание';
    $lang['MultiGallery_edit'] = 'Изменить';
    $lang['MultiGallery_gallery'] = 'Галлереи';
    $lang['MultiGallery_change_desc'] = 'Сохранить изменения';
    $lang['MultiGallery_create'] = 'Создать';
    $lang['MultiGallery_empty'] = 'Галерея пуста!';
    $lang['MultiGallery_foto'] = ' фото';
    $lang['MultiGallery_nofoto'] = 'Ни одной фотографии';
    $lang['MultiGallery_teg'] = 'Тег для вставки в контент:';
    $lang['MultiGallery_teg_all'] = 'Всех изображений галереи ';
    $lang['MultiGallery_teg_gal'] = 'Ссылки на галерею ';
    $lang['MultiGallery_publish'] = ' Опубликовать ';
    $lang['MultiGallery_teg_rand'] = ' Cлучайное изображение из галереи ';
    $lang['MultiGallery_nasv_gal'] = ' Название галлереи ';