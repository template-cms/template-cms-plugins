<?php
	
	$lang['guestbook_title'] = 'Гостевая книга';
	$lang['guestbook_submenu'] = 'Гостевая книга';
	$lang['guestbook_name'] = 'Имя';	
	$lang['guestbook_email'] = 'Емейл';	
	$lang['guestbook_message'] = 'Сообщение';	
	$lang['i_am_not_a_robot'] = 'Я не робот';
	$lang['guestbook_robot'] = 'Ты робот!';	
	$lang['guestbook_empty_name'] = 'Незаполненное поле: имя';
	$lang['guestbook_empty_email'] = 'Незаполненное поле: емейл';
	$lang['guestbook_empty_message'] = 'Незаполненное поле: сообщение';	
	$lang['guestbook_add_comment'] = 'Оставить комментарий';	
	$lang['guestbook_delete_comment'] = 'Удалить';	
	$lang['guestbook_create_db'] = 'База данных создана';
	$lang['guestbook_save'] = 'Сохранить';
	$lang['guestbook_send'] = 'Отправить';
    $lang['guestbook_wrong_email'] = 'Неправильный емейл';
    $lang['guestbook_crypt'] = 'Заполните здесь текст в картинке';
    