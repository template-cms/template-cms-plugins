<?php

	$lang['guestbook_title'] = 'Guestbook';
	$lang['guestbook_submenu'] = 'Guestbook';
	$lang['guestbook_name'] = 'Name';	
	$lang['guestbook_email'] = 'Email';	
	$lang['guestbook_message'] = 'Message';	
	$lang['i_am_not_a_robot'] = 'I am not a robot';
	$lang['guestbook_robot'] = 'You are a robot!';
	$lang['guestbook_empty_name'] = 'Empty field: subject';
	$lang['guestbook_empty_email'] = 'Empty field: email';
	$lang['guestbook_empty_message'] = 'Empty field: message';			
	$lang['guestbook_add_comment'] = 'Leave a comment';	
	$lang['guestbook_delete_comment'] = 'Delete';	
	$lang['guestbook_create_db'] = 'The database was created';
	$lang['guestbook_save'] = 'Save';
	$lang['guestbook_send'] = 'Send';
    $lang['guestbook_wrong_email'] = 'Wrong Email';
    $lang['guestbook_crypt'] = 'Copy the text';   