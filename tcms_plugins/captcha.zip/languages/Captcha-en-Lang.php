<?php

    $lang['captcha_robot'] = 'You are a robot!';    
    $lang['captcha_crypt'] = 'Copy the text';