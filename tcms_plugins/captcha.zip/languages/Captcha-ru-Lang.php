<?php

    $lang['captcha_robot'] = 'Ты робот!';    
    $lang['captcha_crypt'] = 'Заполните здесь текст в картинке';  