<?php

    addHook('admin_pages_second_navigation','adminSecondNavigation',array('pages',lang('news_name'),'news'));
    addHook('admin_headers','newsHeaders');


    /**
     * Add some headers to admin
     */
    function newsHeaders() {
        // some headers to admin...
    }
    
    /**
     * News install
     */
    function newsInstall() {
        $news_dir  = '../data/news/';
        $news_content_dir  = $news_dir.'content/';

        // Create directory and index and data database
        if(!is_dir($news_dir))  mkdir($news_dir, 0755);
        if(!is_dir($news_content_dir))  mkdir($news_content_dir, 0755);
        createXMLdb($news_dir.'news'); 
        
        addOption('news_template','');
    }
    
    /**
     * News admin
     */
    function newsAdmin() {
        $news_dir  = '../data/news/';
        $news_content_dir  = $news_dir.'content/';
        $news_xml = getXMLdb($news_dir.'news.xml');
        
        $current_theme = getSiteTheme(false);
        $templates_path = TEMPLATE_CMS_THEMES_PATH.$current_theme.'/';
        
        $today = mktime(date('H'), date('i'), date('s'), 
                        date('n'), date('j'), date('Y'));
        //$date = dateFormat($art->date,'d.m.Y');
        
        // Create news
        if(!empty($_POST['news_title_new'])) {
            insertXMLRecord($news_xml,'news',array('title'   =>post('news_title_new'),
                                                         'description' => '',
                                                         'keywords'    => '',
                                                         'slug'    =>safeName(post('news_title_new')),
                                                         'date'    =>$today,
                                                         'notshow' =>'1',
                                                         'views'   => '0'));
            $last_id = lastXMLRecordId($news_xml,'news');
            
            createXMLdb($news_content_dir.$last_id);
            $news_content_xml = getXMLdb($news_content_dir.$last_id.'.xml');
            insertXMLRecord($news_content_xml,'content',array('message'     => ''));
            redirect('index.php?id=pages&sub_id=news&action=edit&art_id='.$last_id);
        }
        
        $templates_list = listFiles($templates_path,'Template.php');
        foreach($templates_list as $file) {
            $pos = strpos($file, 'minify');
            if(!($pos !== false)) {
                $templates_array[] = basename($file,'Template.php');
            }
        }
                    
        // Check for get actions
        if (isGet('action')) {
            // Switch actions
            switch (get('action')) {
                case "delete":
                    if (!empty($_GET['art_id'])){
                        deleteXMLRecord($news_xml,'news',get('art_id')); 
                        deleteFile($news_content_dir.get('art_id').'.xml');
                    }
                    redirect('index.php?id=pages&sub_id=news');
                    break;
                case "settings":
                    if (!empty($_POST['templates'])) {
                        $template = 'news_template';
                        $template_option = getOption($template);
                        if (empty($template_option)) {
                            addOption($template, post('templates'));
                        } else {
                            updateOption($template, post('templates'));
                        }
                        flashMessage(lang('news_saved'));
                    } elseif (!empty($_POST['limit'])) {
                        $limit = 'news_limit';
                        $limit_option = getOption($limit);
                        $limit_value = intval($_POST['limit'])>0 ? post('limit') : 5;
                        if (empty($limit_option)) {
                            addOption($limit, $limit_value);
                        } else {
                            updateOption($limit, $limit_value);
                        }
                        flashMessage(lang('news_saved'));
                    }
                    include 'templates/backend/NewsSettingsTemplate.php';
                    break;
                case "edit":
                    if (!empty($_GET['art_id'])){
                        $news_content_xml = getXMLdb($news_content_dir.get('art_id').'.xml');
                        
                        if((isPost('edit_page') or isPost('edit_page_and_exit')) and !empty($_POST['title'])) {
                            
                            updateXMLRecord($news_xml, 'news', get('art_id'), array('title'   => post('title'),
                                                                                          'description' => post('description'),
                                                                                          'keywords'    => post('keywords'),
                                                                                          'slug'    => safeName(post('slug')),
                                                                                          'notshow' => intval(post('notshow')),
                                                                                          'template'=> post('templates')));
                            
                            updateXMLRecord($news_content_xml, 'content', 1, array('message'     => post('editor')));
                                                                                        
                            if(isPost('edit_page_and_exit')) {
                                redirect('index.php?id=pages&sub_id=news');    
                            } else {
                                redirect('index.php?id=pages&sub_id=news&action=edit&art_id='.get('art_id'));
                            }
                        }
                        
                        $news         = selectXMLRecord($news_xml, '//news[@id='.get('art_id').']');
                        $news_content = selectXMLRecord($news_content_xml, '//content[@id=1]');
                        
                        if(isPost('title')) $art_title = post('title'); else $art_title = toText($news->title);
                        if(isPost('description')) $art_description = post('description'); else $art_description = toText($news->description);
                        if(isPost('keywords')) $art_keywords = post('keywords'); else $art_keywords = toText($news->keywords);
                        if(isPost('slug')) $art_slug = post('slug'); else $art_slug = toText($news->slug);
                        if(isPost('editor')) $art_edit = post('editor'); else $art_edit = toText($news_content->message);
                        if(isPost('notshow')) $art_notshow = intval(post('notshow')); else $art_notshow = intval($news->notshow);
                        if(isPost('templates')) $art_template = post('templates'); else $art_template = toText($news->template);
                        
                        include 'templates/backend/EditNewsTemplate.php';
                    }                    
                    break;
            }
            // Its mean that you can add your own actions for this plugin
            runHook('admin_news_extra_actions');
        } else { // Load main template
            $news = selectXMLRecord($news_xml, "//news",'all');
            include 'templates/backend/NewsTemplate.php';
        }
    }