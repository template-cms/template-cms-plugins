<?php

    /**
     *  News plugin
     *  @package TemplateCMS
     *  @subpackage Plugins
     *  @author Yudin Evgeniy / JEEN
     *  @copyright 2012 Yudin Evgeniy / JEEN
     *  @version 1.0.0
     *
     */

    // Register plugin
    registerPlugin(getPluginId(__FILE__),
                   getPluginFilename(__FILE__),
                   'News',
                   '1.0.0',
                   'News plugin. <a href="index.php?id=pages&sub_id=news">&rarr; admin</a> <a href="../news" target="_blank">&rarr; see</a>',
                   'JEEN',
                   'http://lovetcms.ru/',
                   'newsAdmin',
                   'news');

    // Get language file for this plugin
    getPluginLanguage('News');

    // Include News Admin
    getPluginAdmin('News');
    
    // Frontend hooks
    addHook('news_content','newsContent');
    addHook('news_title','newsTitle');
    addHook('news_keywords','newsKeywords');
    addHook('news_description','newsDescription');
    addHook('news_template','newsTemplate',array());
    addHook('theme_header','newsThemeHeader');
    
    function newsThemeHeader() {
        echo '<style>
            ul.paginator {
                list-style:none;
                margin:0; padding:0;
            }
            
            ul.paginator li {
                margin:0;padding:0;
                float:left;
            }
            
            ul.paginator li a{
                display:block;
                padding:3px 5px;
                margin-right:3px;
                background:#ccc;
                border-radius:3px;
                color:#555;
            }
            
            ul.paginator li a:hover {
                background:#999;
            }
            
            ul.paginator li a.current {
                background:none;
            }
        </style>';
    }
    
    function newsTemplate($uri) {
        $template_def = getOption('news_template');
        if (empty($uri[1])) {
            if(empty($template_def)) return 'index'; else  return $template_def;
        } else {
            $news_xml = getNewsDB();
            $news = selectXMLRecord($news_xml,"//news[slug='".safeName($uri[1])."']",1);
            $template = (string)$news[0]->template;
            if (empty($template)) {
                if (empty($template_def)) return 'index'; else return $template_def;
            } else {
                return $template;
            }
        }
    }
    
    function newsContent($uri) {
        $news_xml = getNewsDB();
        
        if (empty($uri[1]) or $uri[1] == 'page') {
            $records = selectXMLRecord($news_xml, "//news[not(notshow='1')]",'all');
            
            $limit = getOption('news_limit');
            if (empty($limit)) $limit = 5;
            
            $news_count = count($records); // ���-�� ������
            $pages_count = ceil($news_count/$limit); // ���-�� �������
            
            if(empty($uri[1])) $currentPage = 1;
            else $currentPage = intval($uri[2]);
            
            if (($currentPage < 1) or ($currentPage > $pages_count)) {
                newsError();
                statusHeader(404);
            } else {
                $start = $news_count - ($currentPage * $limit);
                
                if ($start < 0) {
                    $limit = $limit + $start;
                    $start = 0;
                }
                
                $records = array_slice($records, $start, $limit);
                $news = selectXMLfields($records, array('id','title','slug'),'date','DESC');
                include 'templates/frontend/NewsTemplate.php';
                
                if ($pages_count > 1) {
                    htmlBr();
                    $pageurl = getSiteUrl(false).'news/page/';
                    $pageP1 = $currentPage + 1;
                    $pageP2 = $currentPage + 2;
                    $pageM1 = $currentPage - 1;
                    $pageM2 = $currentPage - 2;
                    
                    echo '<ul class="paginator">';
                    if ($currentPage != 1) {
                        echo '<li><a href="'.$pageurl.'1">&le;</a></li>';
                        echo '<li><a href="'.$pageurl.$pageM1.'">< '.lang('news_back').'</a></li>';
                    }
                    if($pageM2>0) echo '<li><a href="'.$pageurl.$pageM2.'">'.$pageM2.'</a></li>';
                    if($pageM1>0) echo '<li><a href="'.$pageurl.$pageM1.'">'.$pageM1.'</a></li>';
                    echo '<li><a href="'.$pageurl.$currentPage.'" class="current" title="">'.$currentPage.'</a></li>';
                    if($pageP1<=$pages_count) echo '<li><a href="'.$pageurl.$pageP1.'">'.$pageP1.'</a></li>';       
                    if($pageP2<=$pages_count) echo '<li><a href="'.$pageurl.$pageP2.'">'.$pageP2.'</a></li>';
                    if ($currentPage != $pages_count) {
                        echo '<li><a href="'.$pageurl.$pageP1.'">'.lang('news_next').' ></a></li>';
                        echo '<li><a href="'.$pageurl.$pages_count.'">&ge;</a>';
                    }
                    echo '</ul>';
                }
            }
        } else {
            $records = selectXMLRecord($news_xml,"//news[slug='".safeName($uri[1])."']",1);
            $news = selectXMLfields($records, array('id','title','slug','views'),'id');
            if(count($news) > 0) { 
                $news = $news[0];
                
                $news['message'] = getNewsMessage($news['id']);
            
                if (!isset($_SESSION['news'.$news['id']])) {
                    $_SESSION['news'.$news['id']] = true;
                
                    $news['views'] = intval($news['views'])+1;
                    updateXMLRecord($news_xml,'news',$news['id'],array('views'=>$news['views']));
                }
            
                include 'templates/frontend/ShowNewsTemplate.php';
            } else { 
                newsError();
                statusHeader(404);
            }
        }
    }
    
    function newsList($count=5) {
        $news_xml = getNewsDB();
        
        if ($count == 'all') {
            $records = selectXMLRecord($news_xml, "//news[not(notshow='1')]",'all');
        } else {
            $records = selectXMLRecord($news_xml, "//news[not(notshow='1')]",intval($count));
        }
        $news = selectXMLfields($records, array('id','title','slug'),'id','ASC');
        include 'templates/frontend/LastNewsTemplate.php';
    }
    
    function newsTitle($uri) {
        if (empty($uri[1])) {
            return lang('news_name');
        } else {
            $news_xml = getNewsDB();
        
            $news = selectXMLRecord($news_xml,"//news[slug='".safeName($uri[1])."']",1);
            return $news[0]->title;
        }
    }
    
    function newsDescription($uri) {
        if (!empty($uri[1])) {
            $news_xml = getNewsDB();
        
            $news = selectXMLRecord($news_xml,"//news[slug='".safeName($uri[1])."']",1);
            return $news[0]->description;
        }
    }
    
    function newsKeywords($uri) {
        if (!empty($uri[1])) {
            $news_xml = getNewsDB();
        
            $news = selectXMLRecord($news_xml,"//news[slug='".safeName($uri[1])."']",1);
            return $news[0]->keywords;
        }
    }
    
    function getNewsDB() {
        $news_dir  = TEMPLATE_CMS_DATA_PATH.'news/';
        return getXMLdb($news_dir.'news.xml');
    }
    
    function getNewsMessage($id_news) {
        $news_content_dir = TEMPLATE_CMS_DATA_PATH.'news/content/';
        $news_content_xml = getXMLdb($news_content_dir.$id_news.'.xml');
        $records_content = selectXMLRecord($news_content_xml,"//content[@id=1]",1);
        
        return $records_content[0]->message;
    }
    
    function newsMore($text,$slug) {
        $more = "<!--more-->";
        
        if(preg_match($more,$text)) {
            $text_decode = htmlspecialchars_decode($text);
            $array = explode($more,$text_decode);
            return $array[0].'<div><a href="'.getSiteUrl(false).'news/'.$slug.'" class="more_news">'.lang('news_more').'</a></div>';
        } else {
            return $text;
        }
    }
    
    function newsError() {
        $pages_xml = getXML(TEMPLATE_CMS_DATA_PATH.'pages/error404.xml');
        echo $pages_xml->content;
    }