<h1><?php echo lang('news_name');?></h1>
    
<?php foreach ($news as $art): ?>
    <?php $art['message'] = getNewsMessage($art['id']);?>
    <h2><a href="<?php getSiteUrl();?>news/<?php echo toText($art['slug']);?>"><?php echo toText($art['title']); ?></a></h2>
    <div><?php echo newsMore($art['message'],toText($art['slug']));?></div><br/>
<?php endforeach;?>