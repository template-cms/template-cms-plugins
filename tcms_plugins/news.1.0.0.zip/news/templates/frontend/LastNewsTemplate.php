<?php foreach ($news as $art): ?>
    <li><a href="<?php getSiteUrl();?>news/<?php echo toText($art['slug']);?>"><?php echo toText($art['title']); ?></a></li>
<?php endforeach;?>