<h1><a href="<?php getSiteUrl();?>news"><?php echo lang('news_name');?></a> &rarr; <?php echo toText($news['title']); ?></h1>

<div><?php echo $news['message'];?></div><br/>

<div><?php echo lang('news_views');?> <b><?php echo intval($news['views']);?></b></div><br/>

<?php if ($_SESSION['admin']):?>
<a href="<?php getSiteUrl();?>admin/index.php?id=pages&sub_id=news&action=edit&art_id=<?php echo $news['id'];?>"><?php echo lang('news_edit');?></a>
<?php endif;?>