<?php 
    htmlAdminHeading(lang('news_template'));
    htmlFormOpen('');
    htmlSelect($templates_array,array('name'=>'templates','style'=>'width:200px;'),'',getOption('news_template'));
    htmlNbsp(2);
    htmlFormClose(true, array('name'=>'submit','value'=>lang('news_ready')));
    
    htmlAdminHeading(lang('news_limit'));
    htmlFormOpen('');
    htmlFormInput(array('name'=>'limit','size'=>'50','value'=>getOption('news_limit')));
    htmlNbsp(2);
    htmlFormClose(true, array('name'=>'submit','value'=>lang('news_ready')));