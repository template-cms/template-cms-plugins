<?php
	
    $lang['news_name']        = 'News';
    $lang['news_title_new']   = 'Title';
    $lang['news_title']       = 'Title';
    $lang['news_description'] = 'Description';
    $lang['news_keywords']    = 'Keywords';
    $lang['news_save']        = 'Save';
    $lang['news_edit']        = 'Edit';
    $lang['news_delete']      = 'Delete';
    $lang['news_edit_title']  = 'Edit news';
    $lang['news_slug']        = 'Slug';
    $lang['news_more']        = 'More &rarr;';
    $lang['news_more_info']   = '<b>Tip!</b> Use the tag <b>&lt;!--more--&gt;</b> to reduce the news';
    $lang['news_views']       = 'Views:';
    $lang['news_notshow']     = 'Do not show';
    $lang['news_on']          = 'On';
    $lang['news_off']         = 'Off';
    $lang['news_template']    = 'Template';
    $lang['news_template_art'] = 'Template news';
    $lang['news_template_def'] = '- Default -';
    $lang['news_ready']       = 'Ready';
    $lang['news_saved']       = 'Saved';
    $lang['news_settings']    = 'Settings';
    $lang['news_back']        = 'Back';
    $lang['news_next']        = 'Next';
    $lang['news_limit']       = 'Limit';