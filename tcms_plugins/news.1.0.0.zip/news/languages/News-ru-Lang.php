<?php

    $lang['news_name']        = 'Новости';
    $lang['news_title_new']   = 'Заголовок для новой новости';
    $lang['news_title']       = 'Заголовок новости';
    $lang['news_description'] = 'Краткое описание (description)';
    $lang['news_keywords']    = 'Ключевые слова (keywords)';
    $lang['news_save']        = 'Создать';
    $lang['news_edit']        = 'Редактировать';
    $lang['news_delete']      = 'Удалить';
    $lang['news_edit_title']  = 'Редактировать новость';
    $lang['news_slug']        = 'Слаг (slug)';
    $lang['news_more']        = 'Читать далее &rarr;';
    $lang['news_more_info']   = '<b>Подсказка!</b> Используйте тег <b>&lt;!--more--&gt;</b> для сокращения новости';
    $lang['news_views']       = 'Количество просмотров:';
    $lang['news_notshow']     = 'Не отображать новость';
    $lang['news_on']          = 'Вкл.';
    $lang['news_off']         = 'Выкл.';
    $lang['news_template']    = 'Шаблон для плагина по умолчанию';
    $lang['news_template_art'] = 'Шаблон новости';
    $lang['news_template_def'] = '- По умолчанию -';
    $lang['news_ready']       = 'Готово';
    $lang['news_saved']       = 'Сохранено';
    $lang['news_settings']    = 'Настройки';
    $lang['news_back']        = 'Назад';
    $lang['news_next']        = 'Вперед';
    $lang['news_limit']       = 'Количество новостей на странице';