<?php

    $lang['simplegallery_submenu'] = 'Галерея';
    $lang['simplegallery_name'] = 'Галерея';
    $lang['simplegallery_thumbnail_width'] = 'Ширина превьюшек';
    $lang['simplegallery_thumbnail_height'] = 'Высота превьюшек';
    $lang['simplegallery_thumbnail_count'] = 'Выводить в галереи по:';
    $lang['simplegallery_save_options'] = 'Сохранить';
    $lang['simplegallery_upload'] = 'Загрузить';
    $lang['simplegallery_empty'] = 'Пусто...';
    $lang['simplegallery_delete'] = 'удалить';
    $lang['simplegallery_see'] = 'Посмотреть галерею';
