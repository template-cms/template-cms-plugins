<?php	

    $lang['simplegallery_submenu'] = 'Gallery';
    $lang['simplegallery_name'] = 'Gallery';
    $lang['simplegallery_thumbnail_width'] = 'Width (thumbs)';
    $lang['simplegallery_thumbnail_height'] = 'Height (thumbs)';
    $lang['simplegallery_thumbnail_count'] = 'Display in the gallery:';
    $lang['simplegallery_save_options'] = 'Save';
    $lang['simplegallery_upload'] = 'Upload';
    $lang['simplegallery_empty'] = 'Empty...';
    $lang['simplegallery_delete'] = 'delete';
    $lang['simplegallery_see'] = 'View gallery';
