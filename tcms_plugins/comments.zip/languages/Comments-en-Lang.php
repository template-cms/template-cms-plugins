<?php
	
    $lang['comments_submenu'] = 'Comments';
    $lang['comments_comments'] = 'Comments';
    $lang['comments_name'] = 'Name';
    $lang['comments_email'] = 'Email';
    $lang['comments_message'] = 'Message';
    $lang['comments_send'] = 'Send';
    $lang['i_am_not_a_robot'] = 'I am not a robot';
    $lang['comments_empty_name'] = 'Empty field: name';
    $lang['comments_empty_email'] = 'Empty field: email';
    $lang['comments_empty_message'] = 'Empty message';
    $lang['comments_robot'] = 'You are a robot!';
    $lang['comments_wrong_email'] = 'Wrong email';
    $lang['comments_leave_a_reply'] = 'Leave a replay';
    $lang['comments_page'] = 'Page';
    $lang['comments_delete'] = 'Delete';
    $lang['comments_save'] = 'Save';
    $lang['comments_last_comments_widget'] = 'Widget comments count';