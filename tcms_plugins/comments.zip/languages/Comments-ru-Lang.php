<?php

    $lang['comments_submenu'] = 'Комментарии';
    $lang['comments_comments'] = 'Комментарии';
    $lang['comments_name'] = 'Имя';
    $lang['comments_email'] = 'Емейл';
    $lang['comments_message'] = 'Сообщение';
    $lang['comments_send'] = 'Отправить';
    $lang['i_am_not_a_robot'] = 'Я не робот';
    $lang['comments_empty_name'] = 'Незаполненное поле: имя';
    $lang['comments_empty_email'] = 'Незаполненное поле: емейл';
    $lang['comments_empty_message'] = 'Незаполненное поле: сообщение';
    $lang['comments_robot'] = 'Ты робот!';
    $lang['comments_wrong_email'] = 'Неправильный емейл';
    $lang['comments_leave_a_reply'] = 'Написать ответ';
    $lang['comments_page'] = 'Страница';
    $lang['comments_delete'] = 'Удалить';
    $lang['comments_save'] = 'Сохранить';
    $lang['comments_last_comments_widget'] = 'Комментариев в виджете';