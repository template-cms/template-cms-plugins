<?php

    $lang['search'] = 'Search';
    $lang['search_more'] = 'more results...';
    $lang['search_submit'] = 'Search';