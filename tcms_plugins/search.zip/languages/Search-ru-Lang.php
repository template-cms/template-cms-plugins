<?php

    $lang['search'] = 'Поиск';
    $lang['search_more'] = 'еще результаты...';
    $lang['search_submit'] = 'Поиск';