<?php
	
    $lang['sandbox_name'] = 'Sandbox :)';