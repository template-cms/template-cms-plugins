<?php

    $lang['contacts_subject'] = 'Subject';
    $lang['contacts_message'] = 'Message';
    $lang['contacts_form'] = 'Contact form';
    $lang['contacts_contact'] = 'Email';
    $lang['contacts_save'] = 'Save';
    $lang['contacts_send'] = 'Send';
    $lang['i_am_not_a_robot'] = 'I am not a robot';
    $lang['empty_name'] =  'Empty field: subject';
    $lang['empty_contact'] = 'Empty field: email';
    $lang['empty_msg'] = 'Empty field: message';
    $lang['robot'] = 'You are a robot!';
    $lang['letter_sent'] = 'Letter sent';
    $lang['contacts_wrong_email'] = 'Wrong email';