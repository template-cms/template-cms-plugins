<?php

    $lang['contacts_subject'] = 'Тема';
    $lang['contacts_message'] = 'Сообщение';
    $lang['contacts_form'] = 'Контактная форма';
    $lang['contacts_contact'] = 'Емейл';
    $lang['contacts_save'] = 'Сохранить';
    $lang['contacts_send'] = 'Отправить';
    $lang['i_am_not_a_robot'] = 'Я не робот';
    $lang['robot'] = 'Ты робот!';
    $lang['empty_name'] =  'Незаполненное поле: тема';
    $lang['empty_contact'] = 'Незаполненное поле: емейл';
    $lang['empty_msg'] = 'Незаполненное поле: сообщение';
    $lang['letter_sent'] = 'Письмо отправлено';
    $lang['contacts_wrong_email'] = 'Неправильный емейл';
