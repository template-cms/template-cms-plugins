<?php

    $lang['hearts_submenu']  = 'Сердечки';
    $lang['hearts_hearts']  = 'Сердечки';
    $lang['hearts_code_template']  = 'Код для вставки в шаблон'; 
    $lang['hearts_code_text']  = 'Код для вставки в текст';
    $lang['hearts_new_heart_create']  = 'Создать сердечко';   
    $lang['hearts_title']  = 'Заголовок';   
    $lang['hearts_create']  = 'Создать';
    $lang['hearts_counter']  = 'Счетчик';
    $lang['hearts_edit']  = 'Редактировать';
    $lang['hearts_heart_edit']  = 'Редактировать сердечко';  