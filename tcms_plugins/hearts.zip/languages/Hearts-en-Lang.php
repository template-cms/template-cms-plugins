<?php

    $lang['hearts_submenu']  = 'Hearts';
    $lang['hearts_hearts']  = 'Hearts';
    $lang['hearts_code_template']  = 'Code for template'; 
    $lang['hearts_code_text']  = 'Code for text';
    $lang['hearts_new_heart_create']  = 'Create a heart';       
    $lang['hearts_title']  = 'Title';   
    $lang['hearts_create']  = 'Create';      
    $lang['hearts_counter']  = 'Counter';
    $lang['hearts_edit']  = 'Edit';
    $lang['hearts_heart_edit']  = 'Edit heart';