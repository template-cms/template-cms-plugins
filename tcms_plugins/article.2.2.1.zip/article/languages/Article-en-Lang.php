<?php
	
    $lang['article_name']        = 'Article';
    $lang['article_title_new']   = 'Title';
    $lang['article_title']       = 'Title';
    $lang['article_description'] = 'Description';
    $lang['article_keywords']    = 'Keywords';
    $lang['article_save']        = 'Save';
    $lang['article_edit']        = 'Edit';
    $lang['article_delete']      = 'Delete';
    $lang['article_edit_title']  = 'Edit article';
    $lang['article_slug']        = 'Slug';
    $lang['article_more']        = 'More &rarr;';
    $lang['article_more_info']   = '<b>Tip!</b> Use the tag <b>&lt;!--more--&gt;</b> to reduce the news';
    $lang['article_views']       = 'Views:';
    $lang['article_notshow']     = 'Do not show';
    $lang['article_on']          = 'On';
    $lang['article_off']         = 'Off';
    $lang['article_template']    = 'Template';
    $lang['article_template_art'] = 'Template article';
    $lang['article_template_def'] = '- Default -';
    $lang['article_ready']       = 'Ready';
    $lang['article_saved']       = 'Saved';
    $lang['article_settings']    = 'Settings';
    $lang['article_back']        = 'Back';
    $lang['article_next']        = 'Next';
    $lang['article_limit']       = 'Limit';