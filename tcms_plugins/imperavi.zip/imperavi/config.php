<?php

	define('SYSTEM_ROOT', 'data/files/');
	define('FILES_ROOT', SYSTEM_ROOT.'');
	define('IMAGES_ROOT', SYSTEM_ROOT.'');

?>