<?php
print_r(stripslashes($_POST['redactor']));
?>