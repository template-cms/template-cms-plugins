<?php

	$lang['sr_vote'] = 'Vote';
	$lang['sr_votes'] = 'Votes';
	$lang['sr_rating'] = 'Rating';
