<?php
	
	$lang['sr_vote'] = 'Голосовать';
	$lang['sr_votes'] = 'Голосов';
	$lang['sr_rating'] = 'Рейтинг';

    